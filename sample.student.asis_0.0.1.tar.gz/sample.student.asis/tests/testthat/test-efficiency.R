# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

test_that("the samplers are efficient", {
  skip("This test is meant for manual execution and inspection.")

  draws <- 30000L
  thin <- seq(500, draws, by = 2)

  set.seed(45)
  y1 <- rt(500, df = 250)
  sample11 <- dfsample(y1, draws = draws, strategy = "a")
  sample12 <- dfsample(y1, draws = draws, strategy = "s")
  sample13 <- dfsample(y1, draws = draws %/% 2, strategy = "sa")

  set.seed(46)
  y2 <- rt(500, df = 2)
  sample21 <- dfsample(y2, draws = draws, strategy = "a", on_underflow = "warning")
  sample22 <- dfsample(y2, draws = draws, strategy = "s")
  sample23 <- dfsample(y2, draws = draws %/% 2, strategy = "sa", on_underflow = "warning")

  mean(head(sample11$nu, -1) != tail(sample11$nu, -1))
  mean(head(sample12$nu, -1) != tail(sample12$nu, -1))
  mean(head(sample13$nu, -1) != tail(sample13$nu, -1))
  mean(head(sample21$nu, -1) != tail(sample21$nu, -1))
  mean(head(sample22$nu, -1) != tail(sample22$nu, -1))
  mean(head(sample23$nu, -1) != tail(sample23$nu, -1))
  plot.ts(sample11$nu[thin])
  plot.ts(sample12$nu[thin])
  plot.ts(sample13$nu[thin])
  plot.ts(sample21$nu[thin])
  plot.ts(sample22$nu[thin])
  plot.ts(sample23$nu[thin])
  summary(sample11$nu[thin])
  summary(sample12$nu[thin])
  summary(sample13$nu[thin])
  summary(sample21$nu[thin])
  summary(sample22$nu[thin])
  summary(sample23$nu[thin])
  coda::effectiveSize(sample11$nu[thin])
  coda::effectiveSize(sample12$nu[thin])
  coda::effectiveSize(sample13$nu[thin])
  coda::effectiveSize(sample21$nu[thin])
  coda::effectiveSize(sample22$nu[thin])
  coda::effectiveSize(sample23$nu[thin])
})
