# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

test_that("Geweke-test passes for ancillarity", {
  skip("This test is meant for manual execution and inspection.")

  prior_rate <- 0.05
  aa <- geweke_ancillarity(n = 3L, prior_rate = prior_rate, draws = 50000L, lower_bound = 2.1)
  nu <- tail(aa$nu, -1000)  # burnin, not necessarily needed
  mean(head(nu, -1) != tail(nu, -1))  # MH acceptance rate
  quantile(pexp(nu - 2.1, prior_rate), (1:9)/10)  # Geweke-test: quantiles should match
  plot.ts(nu)  # traceplot
  coda::effectiveSize(nu)  # effective sample size
})

test_that("Geweke-test passes for sufficiency", {
  skip("This test is meant for manual execution and inspection.")

  prior_rate <- 0.5
  ss <- geweke_sufficiency(n = 3L, prior_rate = prior_rate, draws = 500000L, lower_bound = 0)
  nu <- ss$nu
  mean(head(nu, -1) != tail(nu, -1))  # "acceptace rate" (this is iid sampling)
  quantile(pexp(nu - 0, prior_rate), (1:9)/10)  # Geweke-test: quantiles should match
  plot.ts(nu)  # traceplot
  coda::effectiveSize(nu)  # effective sample size
})
