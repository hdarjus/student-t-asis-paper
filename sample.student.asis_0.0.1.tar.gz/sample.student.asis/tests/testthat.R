library(testthat)
library(sample.student.asis)

test_check("sample.student.asis")
