# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

# tested using
# quantile(pt(sqrt(1.2) * simulate_ancillarity(100000, 12)$y, df = 12), probs = (1:9)/10)
#' @export
simulate_ancillarity <- function (n, nu, u = NULL) {
  if (is.null(u)) {
    u <- runif(n)
  }
  y <- rnorm(n, 0, sqrt(qinvgamma(u, nu)))
  list(y = y, u = u, nu = nu)
}

# tested using
# quantile(pt(sqrt(1.2) * simulate_sufficiency(100000, 12)$y, df = 12), probs = (1:9)/10)
#' @export
simulate_sufficiency <- function (n, nu, tau = NULL) {
  if (is.null(tau)) {
    tau <- 1 / rgamma(n, 0.5 * nu, 0.5 * nu)
  }
  y <- rnorm(n, 0, sqrt(tau))
  list(y = y, tau = tau, nu = nu)
}
