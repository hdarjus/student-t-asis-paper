# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

#' @export
pinvgamma <- function (tau, nu) {
  pgamma(1 / tau, 0.5 * nu, 0.5 * nu, lower.tail = FALSE)
}

#' @export
pinvgamma_general <- function (tau, shape, scale) {
  pgamma(1 / tau, shape, rate = scale, lower.tail = FALSE)
}

#' @export
qinvgamma <- function (u, nu) {
  1 / qgamma(1 - u, 0.5 * nu, 0.5 * nu)
}

#' @export
logdinvgamma <- function (tau, nu) {
  -2 * log(tau) + dgamma(1 / tau, 0.5 * nu, 0.5 * nu, log = TRUE)
}
