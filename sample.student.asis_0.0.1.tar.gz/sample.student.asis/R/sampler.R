# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

#' Sampling the Degrees of Freedom Parameter for the Student-t Distribution
#'
#' The implementation of the three Gibbs-samplers that are investigated in the
#' attached paper.
#' @param y (numeric vector) of input data
#' @param draws (integer) number of draws after the burnin
#' @param burnin (integer) number of draws to throw away at the beginning
#' @param prior_rate (positive number) rate of the exponential distribution
#' @param strategy (one of \code{"a"}, \code{"s"}, or \code{"sa"}) ancillarity,
#' sufficiency, or ASIS sampling strategy, respectively
#' @param on_underflow (one of \code{"error"}, \code{"warning"}, or \code{"reject"})
#' what should happen when the ancillarity sampler experiences a numeric error?
#' Error stops, warning just signals, reject silently moves on while rejecting these draws.
#' @param store_latent_indices (vector of indices) specifies which elements of the
#' latent vectors should be stored; useful for saving on storage
#' @param init_nu (positive number) a valid initial value for \code{nu}
#' @param lower_bound (non-negative number) in case \code{nu} should be restricted
#' from below, for example when a finite variance is wished for, the sampler will
#' assume a prior distribution that is shifter to the positive direction by
#' \code{lower_bound}; e.g. for \code{lower_bound==2}, one assumes \code{nu>2}.
#' @param target_acceptance (number between 0 and 1) the target acceptance for the
#' adaptive Metropolis algorithm
#' @importFrom progress progress_bar
#' @export
dfsample <- function (y, draws = 10000L, burnin = 0L, prior_rate = 0.1, strategy = "sa",
                      on_underflow = "reject", store_latent_indices = seq_along(y),
                      init_nu = NA, lower_bound = 0, target_acceptance = 0.44) {
  if (!(strategy %in% c("a", "s", "sa"))) {
    stop("Incorrect input for 'strategy'.")
  }
  if (lower_bound > 0 && strategy != "a") {
    stop("Not yet implemented. Lower bound for 'nu' should be 0 for the sufficiency strategy!")
  }
  parameterization <- strsplit(strategy, "")[[1]]
  do_ancillarity <- "a" %in% parameterization
  do_sufficiency <- "s" %in% parameterization
  n <- length(y)

  # for adaptation
  update_nu_ancillarity <- if (do_ancillarity)
    construct_nu_ancillarity_sampler(prior_rate = prior_rate,
                                     lower_bound = lower_bound,
                                     on_underflow = on_underflow,
                                     target_acceptance = target_acceptance)
  else
    NULL
  #update_nu_sufficiency <- if (do_sufficiency)
  #  construct_nu_sufficiency_sampler(prior_rate = prior_rate,
  #                                   lower_bound = lower_bound,
  #                                   target_acceptance = target_acceptance)
  #else
  #  NULL
  #update_u_vector <- if (do_ancillarity) construct_u_sampler(n) else NULL

  pb <- progress::progress_bar$new(
    format = " [:bar] :percent eta: :eta",
    total = (draws + burnin) %/% 20L, clear = FALSE, width= 60)
  pb$tick(0)

  # initialize
  nu <- if (is.na(init_nu)) 5 else init_nu
  u <- if (do_ancillarity) runif(n, 0.7, 0.8) else NA

  # storage
  store_nu <- numeric(draws * length(parameterization))
  store_tau <- matrix(nrow = length(store_latent_indices), ncol = do_sufficiency * draws)
  store_u <- matrix(nrow = length(store_latent_indices), ncol = do_ancillarity * draws)
  store_underflow <- logical((burnin + draws) * do_ancillarity)  # initializes to FALSE

  nu_a_index <- which("a" == parameterization)
  nu_s_index <- which("s" == parameterization)
  n_params <- length(parameterization)
  for (m in seq_len(burnin + draws)) {
    if (m %% 20L == 0) {
      pb$tick()
    }
    tau <- update_tau_vector(y, nu)
    if (do_sufficiency) {
      nu <- update_nu_sufficiency(tau = tau, prior_rate = prior_rate, lower_bound = lower_bound)
      if (m > burnin) {
        store_tau[, m - burnin] <- tau[store_latent_indices]
        store_nu[n_params * (m - burnin - 1L) + nu_s_index] <- nu
      }
    }
    if (do_ancillarity) {
      u <- pinvgamma(tau, nu)
      nu <- update_nu_ancillarity(nu, y, u)
      if (!is.finite(nu[1])) {
        nu <- nu[2]
        store_underflow[m] <- TRUE
      }
      if (m > burnin) {
        store_u[, m - burnin] <- u[store_latent_indices]
        store_nu[n_params * (m - burnin - 1L) + nu_a_index] <- nu
      }
    }
  }

  list(nu = store_nu,
       tau = store_tau,
       u = store_u,
       underflow = store_underflow)
}

#' @export
log_likelihood_ancillarity <- function (y, u, nu) {
  invgamma_values <- qinvgamma(u, nu)
  dnorm(y, 0, sqrt(invgamma_values), log = TRUE) #- logdinvgamma(invgamma_values, nu)
}

#' @export
log_likelihood_sufficiency <- function (y, tau) {
  dnorm(y, 0, sqrt(tau), log = TRUE)
}

#' @export
construct_nu_ancillarity_sampler <- function (prior_rate = 0.1, lower_bound = 1.9,
                                              on_underflow = "reject",
                                              target_acceptance = 0.44) {
  batch_size <- 200L
  n_repeat <- 20L
  memory <- numeric(batch_size * n_repeat)
  batch_i <- 1L
  count_acceptance <- 0L
  init_gamma <- 0.99
  gamma <- 0.99
  alpha <- 0.97
  adapt_mean <- 0
  adapt_var <- 1
  scale <- 1
  randomize_1_or <- function (value, probability_of_value) {
    if (probability_of_value >= 1 || runif(1) < probability_of_value) value else 1
  }

  update_nu_ancillarity <- function (nu, y, u) {
    for (iii in 1:n_repeat) {
      random_walk_sd <- sqrt(adapt_var) * scale
      log_nu <- log(nu - lower_bound)
      log_nu_prop <- rnorm(1, log_nu, random_walk_sd)
      #while (log_nu_prop <= 0) {
      #  log_nu_prop <- rnorm(1, log_nu, random_walk_sd)
      #}
      nu_prop <- exp(log_nu_prop) + lower_bound
      acceptance_rate <- sum(log_likelihood_ancillarity(y, u, nu_prop)) +
        dexp(nu_prop - lower_bound, prior_rate, log = TRUE) -
        dnorm(nu_prop, nu, random_walk_sd, log = TRUE) + log_nu_prop -
        sum(log_likelihood_ancillarity(y, u, nu)) -
        dexp(nu - lower_bound, prior_rate, log = TRUE) +
        dnorm(nu, nu_prop, random_walk_sd, log = TRUE) - log_nu
      accepted <- acceptance_rate > 0 || exp(acceptance_rate) > runif(1)
      if (!is.finite(accepted)) {
        text <- "Early stop due to underflow! For this data set, please use 'parameterization = \"s\"'."
        switch (on_underflow,
          error = stop(text),
          warning = {warning(text); return(c(NA, nu))},
          reject = return(c(NA, nu)),
          stop("Unknown option for 'on_error'.")
        )
      }
      nu_new <- if (accepted) { nu_prop } else { nu }
      log_nu_new <- if (accepted) { log_nu_prop } else { log_nu }

      # adapted MH
      if (gamma > 0.00001) {
        memory[batch_i] <<- log_nu_new
        count_acceptance <<- count_acceptance + (nu != nu_new)
        if (batch_i < length(memory)) {
          batch_i <<- batch_i + 1L
        } else {
          i_previous <- floor((init_gamma / gamma)^(1 / alpha))
          gamma <<- init_gamma * (i_previous + 1)^(-alpha)
          scale <<- if (count_acceptance > 5L) {
            # set new scale
            probability_of_change <- 100 * gamma / init_gamma
            relative_acceptance <- count_acceptance / (length(memory) - 1) / target_acceptance
            #print(relative_acceptance)
            memory <<- memory - adapt_mean
            adapt_mean <<- adapt_mean + gamma * (mean(memory) - adapt_mean)
            adapt_var <<- adapt_var + gamma * (sum(memory^2) / (length(memory) - 1L) - adapt_var)
            if (relative_acceptance < 0.2) {
              scale * randomize_1_or(.1, probability_of_change)
            } else if (relative_acceptance > 3) {
              scale * randomize_1_or(5, probability_of_change)
            } else if (relative_acceptance < 0.5) {
              scale * randomize_1_or(0.75, probability_of_change)
            } else if (relative_acceptance < 1) {
              scale * randomize_1_or(0.95, probability_of_change)
            } else if (relative_acceptance < 1.8) {
              scale * randomize_1_or(1.05, probability_of_change)
            } else {
              scale * randomize_1_or(1.5, probability_of_change)
            }
          } else {
            scale * 0.05
          }
          batch_i <<- 1L
          count_acceptance <<- 0L
        }
      }
      nu <- nu_new
    }

    nu
  }

  update_nu_ancillarity
}

#' @export
update_nu_sufficiency <- function (tau, prior_rate = 0.1, lower_bound = 0) {
  sufficient_statistic <- prior_rate + 0.5 * sum(1/tau + log(tau))
  n <- length(tau)
  to_solve <- function (xi, ss = sufficient_statistic, len = n) {
    (log(xi / 2) + 1 - digamma(xi / 2)) * len / 2 + 1 / xi - ss
  }
  l <- 1; u <- 10 * l
  while (to_solve(l) < 0) {
    l <- l / 10; u <- u / 10
  }
  while (to_solve(u) > 0) {
    l <- l * 10; u <- u * 10
  }
  optim_obj <- uniroot(to_solve, ss = sufficient_statistic, len = n,
                       lower = l, upper = u, extendInt = "downX")
  xi_star <- optim_obj$root
  log_precomputed <- sufficient_statistic * xi_star - 1 -
    n * ((xi_star / 2) * log(xi_star / 2) - lgamma(xi_star / 2))
  while (TRUE) {
    prop <- rexp(1, rate = 1 / xi_star)
    log_alpha <- log_precomputed + prop * (1 / xi_star - sufficient_statistic) +
      n * ((prop / 2) * log(prop / 2) - lgamma(prop / 2))
    if (log_alpha > 0 || exp(log_alpha) > runif(1)) {
      return(prop)
    }
  }
}

#' @export
construct_nu_sufficiency_sampler <- function (prior_rate = 0.1, lower_bound = 1.9,
                                              target_acceptance = 0.234) {
  memory <- numeric(200L)
  batch_i <- 1L
  count_acceptance <- 0L
  init_gamma <- 0.99
  gamma <- 0.99
  alpha <- 0.97
  adapt_mean <- 0
  adapt_var <- 1
  scale <- 1
  randomize_1_or <- function (value, probability_of_value) {
    if (probability_of_value >= 1 || runif(1) < probability_of_value) value else 1
  }

  update_nu_sufficiency <- function (nu, tau) {
    random_walk_sd <- sqrt(adapt_var) * scale
    log_nu <- log(nu - lower_bound)
    log_nu_prop <- rnorm(1, log_nu, random_walk_sd)
    #while (log_nu_prop <= 0) {
    #  log_nu_prop <- rnorm(1, log_nu, random_walk_sd)
    #}
    nu_prop <- exp(log_nu_prop) + lower_bound
    acceptance_rate <- sum(logdinvgamma(tau, nu_prop)) +
      dexp(nu_prop - lower_bound, prior_rate, log = TRUE) +
      log_nu_prop -
      sum(logdinvgamma(tau, nu)) -
      dexp(nu - lower_bound, prior_rate, log = TRUE) -
      log_nu
    # - dnorm(log_nu_prop, log_nu, random_walk_sd, log = TRUE)
    # + dnorm(log_nu, log_nu_prop, random_walk_sd, log = TRUE)
    accepted <- acceptance_rate > 0 || exp(acceptance_rate) > runif(1)
    nu_new <- if (accepted) { nu_prop } else { nu }
    log_nu_new <- if (accepted) { log_nu_prop } else { log_nu }

    # adapted MH
    if (gamma > 0.00001) {
      memory[batch_i] <<- log_nu_new
      count_acceptance <<- count_acceptance + (nu != nu_new)
      if (batch_i < length(memory)) {
        batch_i <<- batch_i + 1L
      } else {
        i_previous <- floor((init_gamma / gamma)^(1 / alpha))
        gamma <<- init_gamma * (i_previous + 1)^(-alpha)
        scale <<- if (count_acceptance > 5L) {
          # set new scale
          probability_of_change <- 100 * gamma / init_gamma
          relative_acceptance <- count_acceptance / (length(memory) - 1) / target_acceptance
          #print(relative_acceptance)
          memory <<- memory - adapt_mean
          adapt_mean <<- adapt_mean + gamma * (mean(memory) - adapt_mean)
          adapt_var <<- adapt_var + gamma * (sum(memory^2) / (length(memory) - 1L) - adapt_var)
          if (relative_acceptance < 0.2) {
            scale * randomize_1_or(.1, probability_of_change)
          } else if (relative_acceptance > 3) {
            scale * randomize_1_or(5, probability_of_change)
          } else if (relative_acceptance < 0.5) {
            scale * randomize_1_or(0.75, probability_of_change)
          } else if (relative_acceptance < 1) {
            scale * randomize_1_or(0.95, probability_of_change)
          } else if (relative_acceptance < 1.8) {
            scale * randomize_1_or(1.05, probability_of_change)
          } else {
            scale * randomize_1_or(1.5, probability_of_change)
          }
        } else {
          scale * 0.05
        }
        batch_i <<- 1L
        count_acceptance <<- 0L
      }
    }

    nu_new
  }

  update_nu_sufficiency
}

#' @export
construct_u_sampler <- function (n) {
  memory <- matrix(nrow = n, ncol = 200L)
  batch_i <- 1L
  count_acceptance <- rep.int(0L, n)
  target_acceptance <- 0.334
  init_gamma <- 0.99
  gamma <- 0.99
  alpha <- 0.97
  adapt_mean <- rep.int(0, n)
  adapt_var <- rep.int(1, n)
  scale <- rep.int(3, n)
  randomize_1_or <- function (value, probability_of_value) {
    if (probability_of_value >= 1 || runif(1) < probability_of_value) value else 1
  }

  update_u_vector <- function (u, y, nu) {
    random_walk_sd_vector <- sqrt(adapt_var) * scale
    trans_u <- qlogis(u)
    trans_u_prop <- rnorm(length(u), trans_u, random_walk_sd_vector)
    u_prop <- plogis(trans_u_prop)
    acceptance_rate <- log_likelihood_ancillarity(y, u_prop, nu) +
      log(u_prop * (1 - u_prop)) - log(u * (1 - u)) -
      log_likelihood_ancillarity(y, u, nu)
    # - dnorm(trans_u_prop, trans_u, random_walk_sd_vector, log = TRUE)
    # + dnorm(trans_u, trans_u_prop, random_walk_sd_vector, log = TRUE)
    acceptance_rate[!is.finite(acceptance_rate)] <- -Inf
    accepted <- acceptance_rate > 0 | exp(acceptance_rate) > runif(length(u))
    u_new <- ifelse(accepted, u_prop, u)
    trans_u_new <- ifelse(accepted, trans_u_prop, trans_u)

    # adaptation
    if (gamma > 0.00001) {
      memory[, batch_i] <<- trans_u_new
      count_acceptance <<- count_acceptance + (u != u_new)
      if (batch_i < NCOL(memory)) {
        batch_i <<- batch_i + 1L
      } else {
        i_previous <- floor((init_gamma / gamma)^(1 / alpha))
        gamma <<- init_gamma * (i_previous + 1)^(-alpha)
        scale <<- ifelse(count_acceptance > 5L, {
          # set new scale
          probability_of_change <- 100 * gamma / init_gamma
          relative_acceptance <- count_acceptance / (NCOL(memory) - 1) / target_acceptance
          #print(relative_acceptance)
          memory <<- memory - adapt_mean
          adapt_mean <<- adapt_mean + gamma * (rowMeans(memory) - adapt_mean)
          adapt_var <<- adapt_var + gamma * (rowSums(memory^2) / (NCOL(memory) - 1L) - adapt_var)
          ifelse(relative_acceptance < 0.2,
                 scale * randomize_1_or(.1, probability_of_change),
                 ifelse(relative_acceptance > 3,
                        scale * randomize_1_or(5, probability_of_change),
                        ifelse(relative_acceptance < 0.5,
                               scale * randomize_1_or(0.75, probability_of_change),
                               ifelse(relative_acceptance < 1,
                                      scale * randomize_1_or(0.95, probability_of_change),
                                      ifelse(relative_acceptance < 1.8,
                                             scale * randomize_1_or(1.05, probability_of_change),
                                             scale * randomize_1_or(1.5, probability_of_change))))))
        }, scale * 0.05)
        batch_i <<- 1L
        count_acceptance <<- rep.int(0L, length(y))
      }
    }

    u_new
  }

  update_u_vector
}

#' @export
update_tau_vector <- function (y, nu) {
  1 / rgamma(length(y), 0.5 * (nu + 1), rate = 0.5 * (nu + y^2))
}

#' @export
update_u_vector_gibbs <- function (y, nu) {
  tau <- 1 / rgamma(length(y), 0.5 * (nu + 1), 0.5 * (nu + y^2))
  pinvgamma_general(tau, 0.5 * nu, 0.5 * nu)
}
