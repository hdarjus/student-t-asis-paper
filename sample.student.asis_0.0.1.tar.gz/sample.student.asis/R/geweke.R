# Copyright Darjus Hosszejni (C) 2021
# See files README and LICENCE for further info

#' @export
geweke_ancillarity <- function (n = 1L, prior_rate = 0.1, draws = 30000L, lower_bound = 1.9) {
  update_nu_ancillarity <- construct_nu_ancillarity_sampler(prior_rate, lower_bound,
                                                            on_underflow = "reject",
                                                            target_acceptance = 0.44)
  nu <- rexp(1, prior_rate) + lower_bound
  u <- simulate_ancillarity(n, nu)$u
  store_nu <- numeric(draws + 1L)
  store_u <- matrix(nrow = n, ncol = draws + 1L)
  store_nu[1L] <- nu
  store_u[, 1L] <- u
  for (m in 1:draws) {
    if (m %% 1000 == 0) {
      cat("Done with", m, "\n")
    }
    y <- simulate_ancillarity(n = n, nu = nu, u = u)$y
    u <- update_u_vector_gibbs(y, nu)
    nu <- update_nu_ancillarity(nu = nu, y = y, u = u)
    store_nu[m + 1L] <- nu
    store_u[, m + 1L] <- u
  }

  list(nu = store_nu, u = store_u)
}

#' @export
geweke_sufficiency <- function (n = 1L, prior_rate = 0.1, draws = 160000L, lower_bound = 0) {
  #update_nu_sufficiency <- construct_nu_sufficiency_sampler(prior_rate, lower_bound)
  nu <- rexp(1, prior_rate) + lower_bound
  tau <- simulate_sufficiency(n = n, nu = nu)$tau
  store_nu <- numeric(draws + 1L)
  store_nu[1L] <- nu
  for (m in 1:draws) {
    if (m %% 1000 == 0) {
      cat("Done with", m, "\n")
    }
    y <- simulate_sufficiency(n = n, nu = nu, tau = tau)$y
    tau <- update_tau_vector(y, nu)
    nu <- update_nu_sufficiency(tau = tau, prior_rate = prior_rate, lower_bound = 0)
    store_nu[m + 1L] <- nu
  }
  list(nu = store_nu)
}
